<?php
session_start();
if(isset($_POST['captcha_text']))
{
	if($_POST['captcha_text'] == ($_SESSION['captcha']['code']))
	{
		echo 'varified';
	}
	else
	{
		echo "<script>
					alert('captcha error');
					window.location = 'index.php';
			  </script>";
	}
}
?>
    
    

    

