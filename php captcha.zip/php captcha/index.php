<?php
session_start();

$_SESSION = array();

include("simple-php-captcha.php");
$_SESSION['captcha'] = simple_php_captcha();

?>


   
<?php
echo '<pre>';
print_r($_SESSION);
echo '</pre>';
echo $captcha_sess =  $_SESSION['captcha']['code'];
?>

        
		
<form method='post' action='varify.php'>
	<input autocomplete='off' name='captcha_text' type='text'><br>
	<img src="<?php echo $_SESSION['captcha']['image_src']; ?>" ><br>
	<input type='submit' >
</form>
		
		
    
    

    

