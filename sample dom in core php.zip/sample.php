<link rel="stylesheet" href="http://lsgelection.kerala.gov.in/vendors/css/style.css">
<link rel="stylesheet" href="http://lsgelection.kerala.gov.in/vendors/css/responsive.css">
<link rel="stylesheet" href="http://lsgelection.kerala.gov.in/build/css/app.css">
<?php
	include "simple_html_dom.php";
	$items= array();
	$post = array(
			'form[district]' => '5',
			'form[localBody]' => '894',
			'form[ward]' => '21395',
			'form[pollingStation]' => '25799',
			'form[submit]' => 'submit'
		);

	$ch = curl_init('http://lsgelection.kerala.gov.in/voters/view');
	curl_setopt($ch, CURLOPT_POST, true);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
	curl_setopt($ch, CURLOPT_ENCODING,"");
	
	header('Content-Type: text/html');
	$data = curl_exec($ch);
	echo $data;
		   
	$tr = $html->find('tbody[class="voters-list"] tr td');
	foreach ($tr as $row)
	{
		echo $items[] = $row;
	} 
?>