
full manuel link:

https://simplehtmldom.sourceforge.io/manual.htm