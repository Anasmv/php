<?php
$source_url = $_SERVER['REQUEST_URI'];
if(strpos($source_url, '.php') == false and
strpos($source_url, '/htaccess/path/ajx') == false and
$source_url != '/htaccess/path/ajx' and
$source_url != '/htaccess/path/ajx.php')
{
	
?>

this is path/ajx.php page 
<br>

<br>
<pre>
<?php
print_r($_GET);
?>
</pre>

<?php
}
else
{
	echo 'error page';
}
?>