<?php


//echo $source_url = 'http'.((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off') ? 's' : '').'://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
$source_url = $_SERVER['REQUEST_URI'];
if(strpos($source_url, 'index.php') == false and
( basename($_SERVER['SCRIPT_FILENAME']) == 'index.php') and
(realpath(__FILE__) == realpath( $_SERVER['SCRIPT_FILENAME'] ) and
($_SERVER['REQUEST_METHOD']=='GET'))
)
{
 ?>
<br>
htaccess to change index.php to index
<br><br>
$_GET['id']
<br>
  id value = 
<?php
if(isset($_GET['id']))
{
	echo $_GET['id'];
}
else
{
	echo ' no value ';
}

   
?>
<br>
<br>
<a href="./index.php">index.php</a>
<br>
<a href="./index">index</a>
<br>
<a href="./?id=1">?id=1</a>
<br>
<a href="./index.php?id=1">index.php?id=1</a>
<br>
<a href="./index?id=1">index?id=1</a>
<br>
<a href="./indexpage/1">indexpage/1</a>
<br>
<a href="./i/1/2/3/4">i/1/2/3/4</a>
<br>
<a href="./i">i</a>
<br>
<a href="./ajaxpage/">ajaxpage/</a>
<br>
<?php
}
else
{
	echo 'error page';
}
?>





