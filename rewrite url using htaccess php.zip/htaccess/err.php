error page

<?php
echo $_SERVER['HTTP_REQUEST'];
echo $_SERVER['PHP_SELF'];

echo $_SERVER["HTTP_X_REQUESTED_WITH"];
echo $_SERVER['DOCUMENT_ROOT'];
echo $_SERVER['REMOTE_ADDR'];
echo $_SERVER['REQUEST_METHOD'];
echo realpath(__FILE__);
echo realpath( $_SERVER['SCRIPT_FILENAME'] );
echo $_SERVER['HTTP_REFERER'];
echo basename(__FILE__);
$currentPage = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
echo strcmp(basename($currentPage), basename(__FILE__)) == 0;
echo basename($_SERVER['SCRIPT_FILENAME']);

echo php_sapi_name();


echo $_SERVER['REQUEST_URI'];

echo  basename(__FILE__);

echo $_SERVER["HTTP_X_REQUESTED_WITH"];

?>