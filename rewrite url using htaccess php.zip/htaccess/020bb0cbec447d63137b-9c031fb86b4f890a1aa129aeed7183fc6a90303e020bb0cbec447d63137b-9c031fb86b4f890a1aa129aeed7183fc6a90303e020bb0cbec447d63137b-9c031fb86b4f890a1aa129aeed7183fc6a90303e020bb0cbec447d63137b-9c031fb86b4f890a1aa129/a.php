<?php
$source_url = $_SERVER['REQUEST_URI'];
if($source_url == '/htaccess/i')
{
?>
this is a file in 

020bb0cbec447d63137b-9c031fb86b4f890a1aa129aeed7183fc6a90303e020bb0cbec447d63137b-9c031fb86b4f890a1aa129aeed7183fc6a90303e020bb0cbec447d63137b-9c031fb86b4f890a1aa129aeed7183fc6a90303e020bb0cbec447d63137b-9c031fb86b4f890a1aa129 
folder
<?php
}
else
{
	echo 'error page';
}
?>