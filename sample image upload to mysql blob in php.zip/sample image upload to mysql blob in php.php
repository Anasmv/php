<form method='post' enctype="multipart/form-data" >
	<input type='file' accept="image/jpeg"  name='file_name' ><br>
	<input type='submit' name='submit_name' >
</form>
<?php
$con = mysqli_connect('localhost','root','','database');
if( isset($_POST['submit_name']) and isset($_FILES['file_name']) && ($_FILES['file_name']['size'] > 0) )
{
	$tmpName = $_FILES['file_name']['tmp_name'];
	$fp = fopen($tmpName, 'r');
	$data = fread($fp, filesize($tmpName));
	$base64_data = base64_encode($data);
	fclose($fp);
	echo '<img src="data:image/jpeg;base64,' . $base64_data . '" />';
	$query = "INSERT INTO `table`(`id`, `name`, `file`) VALUES (NULL, '', '$base64_data') ";
	$results = mysqli_query($con, $query);
	if($results)
	{
		print "Image has been uploaded.";
	}
	else
	{
		print "error upload";
	}
}
else
{
	print "choose a image";
}

//fetch data from database 
$select= mysqli_query($con, "SELECT * FROM `table`");
while($loop = mysqli_fetch_array($select)){
	$img= $loop['file']; 
	echo '<img src="data:image/jpeg;base64,' .  $img  . '" />';
}
?>