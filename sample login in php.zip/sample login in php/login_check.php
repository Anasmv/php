<?php
session_start();
echo '<pre>';
print_r($_SESSION);
echo '</pre>';

if(isset($_POST['user']) && isset($_POST['pass']) && isset($_SESSION['token']) && isset($_POST['token']) &&
($_POST['token'] == $_SESSION['token']) && isset($_SERVER['HTTP_X_REQUESTED_WITH']) && 
($_SERVER['HTTP_X_REQUESTED_WITH']  == 'XMLHttpRequest') 
&& isset($_SESSION['captcha']['code']) && ($_SESSION['captcha']['code'] == $_POST['captcha_text']) 
&& (($_SERVER['HTTP_REFERER'] == 'http://localhost/test/php/sample%20login%20in%20php/')
|| ($_SERVER['HTTP_REFERER'] == 'http://localhost/test/php/sample%20login%20in%20php/index.php')) )

{
	$user = $_POST['user'];
	$pass = $_POST['pass'];
	try{ 
		$dbh = new PDO('mysql:host=localhost;dbname=login', 'root', '');
		$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$q = "SELECT pass FROM login WHERE user = :user";
		$sth = $dbh->prepare($q);
		$sth->bindParam(':user', $user);
		$sth->execute();
		$sth->setFetchMode(PDO::FETCH_ASSOC);
		$result = $sth->fetchColumn();
		
		print $password = ( htmlentities($result) );
		if(password_verify($pass, $password))
		{
			$userToken = bin2hex(openssl_random_pseudo_bytes(24));
			//assign the token to a session variable.
			$_SESSION['user_token'] = $userToken;
			$_SESSION['user_token_test'] = base64_encode(hash('sha512',(MD5($userToken)))) ;
			echo "<script>alert('success'); 
			window.location.href = 'home.php';
			</script>";
		}
		else
		{
			echo "<script>alert('user name incorrect')</script>";
		}
		$dbh = null;
	}
    catch(PDOException $e){
		error_log('PDOException - ' . $e->getMessage(), 0);
		http_response_code(500);
		die('Error establishing connection with database');
    }
}
else
{
	http_response_code(404);
	//include('my_404.php'); // provide your own HTML for the error page
	die();
}
?>