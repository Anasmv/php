
<?php
session_start();
if(isset($_SESSION['user_token']) && isset($_SESSION['user_token_test']) &&
$_SESSION['user_token_test'] == base64_encode(hash('sha512',(md5($_SESSION['user_token'])))))
{
	echo 'success';
	echo "<br><a href='?l_id=logout'>logout </a>";
}
else
{
	header('Location: index.php');
	exit;
}

if(isset($_GET['l_id']) && $_GET['l_id'] == 'logout')
{
	session_unset();
	session_destroy();
	header("location:index.php");
	exit;
}
?>